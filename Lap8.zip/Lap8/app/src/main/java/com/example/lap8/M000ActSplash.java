package com.example.lap8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class M000ActSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Full_Screen);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_splash);

        // BÀI 1: CODE RANDOM MÀU NỀN VÀ ICON
        List<Integer> backgroundColors = Arrays.asList(
                R.color.random_blue,
                R.color.random_red,
                R.color.random_yellow
        );

        List<Integer> animalIcons = Arrays.asList(
                R.drawable.ic_penguin,
                R.drawable.ic_dog,     // Cần có các file drawable này
                R.drawable.ic_cat
        );

        Random random = new Random();

        int randomColorId = backgroundColors.get(random.nextInt(backgroundColors.size()));
        int randomIconId = animalIcons.get(random.nextInt(animalIcons.size()));

        LinearLayout mainLayout = findViewById(R.id.splash_main_layout);
        ImageView iconImageView = findViewById(R.id.splash_icon_image);

        mainLayout.setBackgroundColor(ContextCompat.getColor(this, randomColorId));
        iconImageView.setImageResource(randomIconId);

        // BÀI 2 & 4: (Code ví dụ cho loading/chuyển màn hình sau 3 giây)
        // Nếu bạn cần mô phỏng màn hình Loading của Bài 2, thường sẽ là một Runnable
        // chạy sau vài giây để chuyển sang màn hình chính (ví dụ: HomeActivity).
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        Intent intent = new Intent(M000ActSplash.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    }
                },
                3000); // 3000ms = 3 giây
    }
}