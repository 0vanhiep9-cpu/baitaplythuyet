package com.example.lap8;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnToSplash = findViewById(R.id.btn_to_splash);
        Button btnToProfile = findViewById(R.id.btn_to_profile);

        // BÀI 4: ĐIỀU HƯỚNG
        btnToSplash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, M000ActSplash.class);
                startActivity(intent);
            }
        });

        btnToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, M001ActProfile.class);
                startActivity(intent);
            }
        });
    }
}