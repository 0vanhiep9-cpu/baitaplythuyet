package com.example.lap8;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // HomeActivity sử dụng layout đơn giản để hiển thị đã chuyển màn hình thành công
        setContentView(R.layout.activity_home);
    }
}